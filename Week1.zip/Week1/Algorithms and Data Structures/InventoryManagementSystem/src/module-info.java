/**
 * 
 */
/**
 * 
 */
module InventoryManagementSystem {
}