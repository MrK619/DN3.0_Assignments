package cts;

public class FinancialForecasting {
    public static double futureValue(double presentValue, double growthRate, int periods) {
        if (periods == 0) {
            return presentValue;
        } else {
            return futureValue(presentValue * (1 + growthRate), growthRate, periods - 1);
        }
    }
}
