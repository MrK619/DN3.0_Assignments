/**
 * 
 */
/**
 * 
 */
module ECommercePlatform {
}