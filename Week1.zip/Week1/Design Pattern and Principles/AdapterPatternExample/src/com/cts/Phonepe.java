package com.cts;

public class Phonepe {
	private String name = "PhonePe";

	public void sendPayment(double amount) {
		System.out.print(amount + " is transferred from " + name + "!");
	}
}
