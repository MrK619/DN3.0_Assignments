package com.cts;

public class GpayAdapter implements PaymentProcessor {

	private Gpay gpay;

	public GpayAdapter(Gpay gpay) {
		this.gpay = gpay;
	}

	@Override
	public void processPayment(double amount) {
		// TODO Auto-generated method stub
		gpay.doPayment(amount);

	}

}
