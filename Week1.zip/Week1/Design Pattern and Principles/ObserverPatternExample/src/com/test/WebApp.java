package com.test;

public class WebApp implements Observer {
    private String webName;

    public WebApp(String webName) {
        this.webName = webName;
    }

    @Override
    public void update(double stockPrice) {
        System.out.println(webName + " received stock price update: $" + stockPrice);
    }
}
