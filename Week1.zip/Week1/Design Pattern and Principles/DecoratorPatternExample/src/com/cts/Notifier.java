package com.cts;

public interface Notifier {
	void send(String message);
}
