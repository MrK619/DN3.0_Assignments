package com.cts;

public interface Command {
    void execute();
}
