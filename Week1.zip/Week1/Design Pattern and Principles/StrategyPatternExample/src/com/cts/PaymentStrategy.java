package com.cts;

public interface PaymentStrategy {
    void pay(double amount);
}
