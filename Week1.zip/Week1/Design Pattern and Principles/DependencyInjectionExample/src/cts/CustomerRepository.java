package cts;

public interface CustomerRepository {
    Customer findCustomerById(String id);
}
