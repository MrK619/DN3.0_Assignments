package com.cts;

public interface Image {
	void display();
}
