package com.cts;

public class Test {
	public static void main(String[] args) {
		Computer builderObj = new Computer.Builder()
				.setCPU("abc")
				.setRAM(16)
				.setStorage(256)
				.build();
		System.out.print(builderObj.getDetails());
	}
}
